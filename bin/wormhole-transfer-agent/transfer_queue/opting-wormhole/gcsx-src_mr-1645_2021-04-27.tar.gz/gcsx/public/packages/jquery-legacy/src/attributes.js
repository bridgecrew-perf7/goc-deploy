define([
	"./core",
	"./attributes/val",
	"./attributes/attr",
	"./attributes/prop",
	"./attributes/classes"
], function( jQuery ) {

// Return jQuery for attributes-only inclusion
return jQuery;
});
